// Board / plaque shapes: 2D outlines, routed-edge slabs, decorative grooves.
// Use:  use <../../lib/shapes.scad>   (mounting: see attach.scad)
use <core.scad>
// Conventions: 2D outlines are centred on the origin; slabs sit on z=0 (back face) and rise to z=t.
function has_edge_wave(shape) = shape == "arched" || shape == "wave" || shape == "scalloped";   // these add `amp` above and below

PLAQUE_SHAPES  = ["rect", "rounded", "chamfered", "notched", "arched", "wave", "scalloped"];
EDGE_PROFILES  = ["flat", "roundover", "chamfer", "cove", "ogee"];
GROOVE_STYLES  = ["none", "single", "double"];

// ---------- outlines ----------
// size = [length, height] of the plain body; arched/wave/scalloped edges add up to `amp` above and below.
// r = corner radius (rounded), corner cut (chamfered) or notch radius (notched).
module plaque_2d(size, shape="rounded", r=8, amp=5, waves=2, n=160) {
    L = size[0]; H = size[1];
    function edge(t) =
        shape == "arched"    ? amp * sin(180*t) :
        shape == "wave"      ? amp * 0.5 * (1 + cos(360*waves*t)) :
        shape == "scalloped" ? amp * abs(sin(180*max(1, round(waves*4))*t)) : 0;
    if (shape == "rect") square([L, H], center=true);
    else if (shape == "rounded") offset(r=r) offset(delta=-r) square([L, H], center=true);
    else if (shape == "chamfered") offset(delta=r, chamfer=true) offset(delta=-r) square([L, H], center=true);
    else if (shape == "notched") difference() {
        square([L, H], center=true);
        for (sx=[-1,1], sy=[-1,1]) translate([sx*L/2, sy*H/2]) circle(r=r, $fn=48);
    }
    else {
        top = [for (i=[0:n]) let(t=i/n) [-L/2 + t*L,  H/2 + edge(t)]];
        bot = [for (i=[n:-1:0]) let(t=i/n) [-L/2 + t*L, -H/2 - edge(t)]];
        rr = min(r, H/4);
        offset(r=rr) offset(delta=-rr) polygon(concat(top, bot));
    }
}

// ---------- routed edge ----------
// inset of the edge at height z' (0 = bottom of the profile zone, r = top face)
function edge_inset(profile, r, zp) =
    profile == "roundover" ? r - sqrt(max(0, r*r - zp*zp)) :
    profile == "chamfer"   ? zp :
    profile == "cove"      ? sqrt(max(0, r*r - (r - zp)*(r - zp))) :
    profile == "ogee"      ? (zp < r/2 ? sqrt(max(0, pow(r/2,2) - pow(r/2 - zp, 2)))
                                       : r/2 + (r/2 - sqrt(max(0, pow(r/2,2) - pow(zp - r/2, 2))))) :
    0;

// extrude children() (a 2D outline) to thickness t with a routed top edge of size r
module profiled_slab(t, profile="roundover", r=3, steps=8) {
    if (profile == "flat" || r <= 0) linear_extrude(t) children();
    else {
        linear_extrude(t - r + 0.01) children();
        for (k=[1:steps]) translate([0, 0, t - r + (k-1)*r/steps])
            linear_extrude(r/steps + 0.01) offset(delta=-edge_inset(profile, r, k*r/steps)) children();
    }
}

// decorative groove following children() (2D outline), cut down from the top face z=t
module outline_groove(t, inset=5.5, w=0.8, depth=0.8, style="single", gap=1.6) {
    if (style != "none")
        for (i=[0:(style == "double" ? 1 : 0)]) let(d = inset + i*(w + gap))
            translate([0, 0, t - depth]) linear_extrude(depth + 1)
                border_2d(d, w) children();
}

// slab with routed profiles on BOTH edges: top (as profiled_slab) and bottom (mirrored), e.g. a table top with a
// rounded underside. Profiles from EDGE_PROFILES; r_bottom + r_top must not exceed t.
module profiled_slab2(t, top="roundover", r_top=2, bottom="flat", r_bottom=2, steps=8) {
    intersection() {
        profiled_slab(t, top, r_top, steps) children();
        translate([0, 0, t]) mirror([0, 0, 1]) profiled_slab(t, bottom, r_bottom, steps) children();
    }
}
